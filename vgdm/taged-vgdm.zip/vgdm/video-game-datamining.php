<?php
/*
 * Copyright © 2013 Diveen
 * All Rights Reserved.
 *
 * This software is proprietary and confidential to Diveen ReplayParser
 * and is protected by copyright law as an unpublished work.
 *
 * Unauthorized access and disclosure strictly forbidden.
 */

/**
 * @author Mickaël Martin Nevot
 */

define('rGj65F1w', 'mickael-martin-nevot.com');

require_once $_SERVER['DOCUMENT_ROOT'] . '/_assets/config/main.inc.php';
require _MMN_INCLUDE_DIR_ . 'header.inc.php';

require _MMN_RECHERCHE_THESE_DIR_ . 'config/main.inc.php';


// ***

?>
                    <p>
                        *** Services Web: <br/>
                        <a href="open-match-3.php">Open Match 3 (service Web)</a><br/>
                        *** Datawarehouse generator: <br/>
                        <a href="open-match-3-dw-generator.php">Open Match 3 datawarehouse generator</a><br/>
                        <a href="open-match-3-dw-generator-sample.php">Open Match 3 datawarehouse generator (sample)</a><br/>
                        *** Datawarehouse: <br/>
                        <a href="DPlayer.php">DPlayer</a><br/>
                        <a href="DRound.php">DRound</a><br/>
                        <a href="DMatch.php">DMatch</a><br/>
                        <a href="FactOM3.php">FactOM3</a><br/>
                        <a href="CubeOM3.php">CubeOM3</a><br/>
                    </p>

<?php
// ***

//phpinfo();

require _MMN_INCLUDE_DIR_ . 'footer.inc.php';