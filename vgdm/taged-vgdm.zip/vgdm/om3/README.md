# om3
Version de test d'un jeu du type match 3 permettant de conduire des expérimentations servant de support aux recherches de l'équipe BDA
