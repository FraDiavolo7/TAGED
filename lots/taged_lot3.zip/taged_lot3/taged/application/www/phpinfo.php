<?php

phpinfo ();
