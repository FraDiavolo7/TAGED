<?php

include '../src/define.php';

WebServices::handle ( TagedWS::getSelector (), $_REQUEST );

