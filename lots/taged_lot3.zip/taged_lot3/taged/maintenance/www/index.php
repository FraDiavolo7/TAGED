<?php

include '../src/define.php';

$Page = new PageMaintenance ( $_REQUEST );