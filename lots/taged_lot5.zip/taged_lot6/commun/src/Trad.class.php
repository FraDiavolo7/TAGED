<?php

class Trad
{
    const CTXT_GENERAL = "general";
    
    public static function translate ( $Texte, $Context = self::CTXT_GENERAL )
	{
        return $Texte;		
	}
}
